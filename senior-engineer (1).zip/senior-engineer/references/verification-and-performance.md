# Verification and Performance

Read this when choosing checks, writing tests, reporting what was verified, or dealing with slow or resource-hungry code.

## Contents
- Choosing verification
- Test types
- Writing good tests
- Reporting verification honestly
- Performance engineering
- Common bottlenecks
- Caching and concurrency
- Benchmarking hygiene

## Choosing verification

Pick checks that fit the change and the project's existing tooling. Narrow first (the tests for the code you touched), then broad (the full suite, lint, type check, build).

| Change | Useful checks |
|---|---|
| Pure logic, algorithms | unit tests, boundary and property-style cases |
| Data access, queries, migrations | integration tests against a real or realistic database; run the migration up and down on sample data |
| API or service boundary | contract or integration tests; check request and response shapes, status codes, error cases |
| UI behavior | component tests, end-to-end test of the critical flow, manual check in a browser or device when feasible, accessibility checks |
| Refactoring | existing tests unchanged and passing; characterization tests if coverage was thin |
| Bug fix | a test that fails before and passes after |
| Build, config, CI, infrastructure | build or dry-run, lint of config, plan or diff output, staging validation |
| Security-relevant | tests with hostile input, authorization negative cases, dependency audit |
| Performance | before and after measurements on representative data |
| Types or public API | type check, compile, check generated clients and docs |

If the project has a script or Makefile target for checks, use it rather than inventing commands. Find it in the README, `package.json`, `Makefile`, `pyproject.toml`, CI config, or `AGENTS.md`.

## Test types

- **Unit**: one unit of logic in isolation; fast and deterministic.
- **Integration**: several real components together (your code plus a real database or filesystem). Finds the bugs mocks hide.
- **End-to-end**: a user-visible flow through the whole system. Few, slow, valuable for critical paths.
- **Regression**: a test written for a specific bug so it cannot return.
- **Contract**: consumer and provider agree on a boundary (API schema, event format).
- **Static analysis and type checking**: cheap, catch whole classes of defects; treat warnings in changed code as signals.
- **Performance**: benchmarks or load tests where speed or capacity is a requirement.
- **Security**: input fuzzing, authorization checks, dependency and secret scanning.

## Writing good tests

- Test **behavior and contracts**, not implementation details; a refactor that preserves behavior should not break tests.
- Cover the **boundaries and failure paths** (empty, maximum, invalid, unauthorized, timeout, partial failure), not just the happy path.
- Make each test **independent and deterministic**: no shared mutable state, no reliance on order, time, randomness, or network unless controlled.
- Name tests by the behavior they pin: `rejects_refund_after_30_days`.
- Mock at **system boundaries** (network, clock, third-party services), not your own internals. Heavy mocking of internals tests the mocks.
- Make sure the test can fail: a test that cannot fail if the code is wrong is worthless. For bug fixes, watch it fail first.
- Follow the project's test layout, framework, fixtures, and naming.
- Do not write tests merely to raise coverage; do not delete or weaken tests to make a change pass.
- Do not add a test framework when the project has none unless asked; propose it instead.

## Reporting verification honestly

Use precise language:

- **Ran and passed**: "`pnpm test --filter orders`: 42 passed." Include the command.
- **Ran and failed**: say so, with the failure, and whether it predates your change (check by running on the unmodified code if feasible).
- **Could not run**: say exactly what and why ("no database available in this environment", "tests require credentials I do not have").
- **Not applicable**: say why ("no tests exist for this module").

Never write "should work" or "tests pass" for something you did not run. Partial verification stated honestly is more valuable than complete verification claimed falsely.

## Performance engineering

1. **Decide whether there is a problem.** Is there a stated requirement, a measurable user-visible slowness, a cost issue, or an obviously unbounded operation? If not, do not optimize.
2. **Measure first.** Profile or time the real workload to find where time or memory goes. Intuition about hot spots is often wrong.
3. **Fix the biggest bottleneck**, starting with algorithmic and structural causes (complexity, redundant work, unbounded data) before micro-optimizations.
4. **Measure again** to confirm improvement and check for regressions in other metrics (memory, readability, correctness).
5. **Keep the code understandable.** An optimization that costs clarity needs a measured benefit and a comment saying why.

State the number: "p95 dropped from 480 ms to 90 ms on the 10k-row fixture", not "much faster".

## Common bottlenecks

| Resource | Typical causes | Typical fixes |
|---|---|---|
| CPU | quadratic or worse algorithms, repeated parsing, heavy work in loops, wrong data structure | better algorithm or data structure, hoist invariants, batch, move work off the hot path |
| Memory | loading entire datasets, unbounded caches or queues, leaks (listeners, closures, references), large copies | streaming, pagination, bounded caches, release references, avoid needless copies |
| Database | N+1 queries, missing indexes, selecting unused columns, unbounded scans, chatty transactions, lock contention | eager loading or joins, appropriate indexes (check the query plan), projections, pagination, shorter transactions |
| Network | many small calls, large payloads, no compression, serial calls that could be parallel, no timeouts | batching, caching, pagination, compression, concurrency with limits |
| I/O | synchronous blocking, many small reads and writes, unbuffered access | buffering, async or batched I/O, avoid repeated filesystem scans |
| Contention | locks held too long, hot rows or keys, single-threaded choke points | narrow critical sections, partitioning, lock-free structures when justified |

## Caching and concurrency

**Caching** trades correctness for speed. Before adding a cache, define: what is the key, what is the maximum staleness, what invalidates it, how large can it grow, what happens on a miss storm. Prefer fixing the slow computation over caching it. Use the project's existing caching layer.

**Concurrency** adds a bug class. Add it only when the workload needs it. Prefer the language's and project's established primitives (task queues, async, worker pools), bound parallelism, protect shared state, avoid check-then-act, and test under load. Verify correctness under contention, not just speed.

## Benchmarking hygiene

- Use representative data sizes and shapes; tiny fixtures hide scaling problems.
- Warm up, run multiple iterations, report spread (median and p95), not one run.
- Compare under identical conditions (same machine, load, build mode); run before and after.
- Isolate what you measure; avoid measuring logging, network variability, or cold caches by accident.
- Keep benchmark code out of production paths and do not commit one-off scripts unless asked.
