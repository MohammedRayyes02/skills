# Debugging and Code Review

Read this for a bug, a failing test, an incident, or when asked to review code or a diff.

## Contents
- Debugging method
- Debugging anti-patterns
- Special cases
- Code review method
- Severity and categories
- Finding format
- Review checklist
- Reviewing your own diff

## Debugging method

First decide whether the bug is **trivial and well understood** (a typo, an obvious off-by-one with the failing line in front of you). If yes, fix it, verify, and move on. Otherwise:

1. **Reproduce or fully understand the failure.** Get exact inputs, environment, error text, and a repeatable trigger. If you cannot reproduce, say so and work from logs and code reading, but label conclusions accordingly.
2. **Gather evidence before theorizing.** Read the full stack trace, logs, recent changes (`git log`, `git diff`, `git blame` on the area), and the actual values at the failure point. Do not rely on what the code "should" do.
3. **Form hypotheses that can be tested.** Write down two or three candidate causes, each with a prediction ("if this is the cause, then X will be true"). Test the cheapest, most likely first.
4. **Narrow systematically.** Bisect over commits, inputs, or code paths; add temporary logging or assertions; reduce to a minimal reproduction. Change one thing at a time.
5. **Find the root cause, not the symptom.** Ask why repeatedly until you reach something that, if fixed, makes the whole class of failure impossible (wrong assumption, missing validation, bad ordering, shared state). Note contributing factors (missing test, misleading name, unclear contract).
6. **Make the smallest correct fix** at the level of the root cause. Do not mix in cleanups.
7. **Verify.** Confirm the original reproduction failed before the fix and passes after. Run the surrounding tests.
8. **Protect against regression** with a test that fails without the fix, when the project has tests and the bug is testable.
9. **Look for siblings.** Search for the same pattern elsewhere; fix or report them.
10. **Report** the cause, the fix, and what you verified, in plain terms.

## Debugging anti-patterns

- Editing code until the error message disappears.
- Wrapping the failing call in `try/catch` or adding a null check without understanding why the value is null.
- Adding `sleep`, retries, or timeouts to mask a race or ordering bug.
- Changing a test's expectation to match the output without deciding which is right.
- Changing several things at once, so you cannot tell what fixed it.
- Blaming the framework, the environment, or "flakiness" before ruling out your own code.
- Stopping at the first plausible explanation without testing it.

## Special cases

- **Intermittent or flaky failures**: suspect shared state, timing, ordering, time zones, randomness, resource limits, and test isolation. Make the failure frequent (loop, stress, fixed seed) before fixing.
- **Works locally, fails elsewhere**: diff the environments (versions, config, data, permissions, network, case-sensitive paths, locale).
- **Performance regressions**: profile and compare before and after; do not guess (see `verification-and-performance.md`).
- **Data corruption**: stop writes first if possible, preserve evidence, then diagnose; never "clean up" data without approval.
- **Cannot reproduce**: say so, list what you tried, add logging that would capture the failure next time, and avoid claiming a fix.

## Code review method

Review the change and its blast radius, not just the diff lines.

1. **Understand intent**: read the description, linked issue, and tests. What is this supposed to do?
2. **Read the diff in context**: open the surrounding code, callers, and callees. Many defects live in what the diff does not show.
3. **Check behavior against intent**: trace the main path and each edge (empty, null, boundary, error, concurrent).
4. **Verify claims with evidence** when you can: run the tests, reproduce the suspected failure, trace the code path completely. A finding backed by a reproduction or a complete trace is confirmed; anything else is a risk or a question.
5. **Respect project conventions**: judge against the project's standards, not your preferences.
6. **Prioritize**: report what matters most first. Do not bury a critical finding under style notes, and do not pad the review.

## Severity and categories

Every finding gets both a **category** (how sure you are and what kind of issue it is) and a **severity** (how much it matters if real).

**Categories**
1. **Confirmed defect**: demonstrably wrong behavior (reproduced, or a complete trace shows it).
2. **Potential risk**: plausible problem you could not confirm; state what would confirm or refute it.
3. **Maintainability concern**: works today but is hard to understand, change, or test.
4. **Optional improvement**: a better way that is not necessary.
5. **Preference**: personal style with no project rule behind it. Say it is a preference, or leave it out.

**Severity**
- **Critical**: data loss or corruption, security vulnerability, crash or outage on a main path.
- **High**: incorrect behavior in common scenarios, broken contract, serious regression risk.
- **Medium**: incorrect behavior in uncommon scenarios, resource leak, notable performance issue, missing error handling that matters.
- **Low**: minor correctness, clarity, or consistency issues.

Never report a speculative issue as a confirmed bug. Never inflate severity to get attention.

## Finding format

```
[High | Confirmed defect] src/orders/refund.ts:88
Refund amount is computed from the current price, not the price paid, so refunds are wrong after a price change.
Evidence: traced refund() -> getPrice(); test with a price change returns 12.00 instead of 10.00.
Suggested fix: use order_item.unit_price captured at purchase.
```

For a risk: say what you could not verify. ("Potential risk: `cache.get` may return a stale entry after `updateUser`; I could not find an invalidation call. Confirm by checking whether `updateUser` clears this key.")

End the review with a short summary: overall assessment, count of findings by severity, and the one or two things that most need attention.

## Review checklist

Use it to prompt thinking, not as a form to fill in.

- **Correctness**: does it do what was asked? Off-by-one, wrong operator, wrong unit or time zone, inverted condition, unhandled branch?
- **Logic and state**: assumptions about ordering, mutation of shared data, stale caches?
- **Security**: untrusted input reaching queries, commands, paths, or markup; missing authorization; secrets in code or logs.
- **Concurrency**: races, check-then-act, missing locks or transactions, deadlock potential, non-atomic updates.
- **Resources**: unclosed handles, connections, listeners, timers; unbounded growth; missing timeouts.
- **Performance**: N+1 queries, work in hot loops, unbounded reads, accidental quadratic behavior.
- **Data integrity**: constraints, transactions, partial failure, idempotency, migration safety.
- **Compatibility**: breaking changes to public interfaces, schemas, config, or file formats; every consumer updated?
- **Error handling**: errors swallowed, misleading messages, missing cleanup on failure paths.
- **Tests**: do they test meaningful behavior and failure cases? Would they fail if the code were wrong?
- **Maintainability and architecture**: unnecessary complexity, duplicated business logic, boundary violations, surprising behavior, unclear naming.
- **Scope**: does the diff contain unrelated changes?

## Reviewing your own diff

Before reporting any implementation as done, review your own change using the same standard: read the full diff, look for leftover debugging, unrelated edits, missed callers, unhandled edge cases, and anything you would question in someone else's pull request.
