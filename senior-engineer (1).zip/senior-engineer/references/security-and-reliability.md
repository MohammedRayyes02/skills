# Security and Reliability

Read this when handling untrusted input, authentication or authorization, secrets, dependencies, failure behavior, or deployment-affecting changes. Apply the controls that fit the project type; not every item applies to every project.

## Contents
- Thinking about trust
- Security controls
- Dependencies and supply chain
- Reliability
- Observability
- Deployment safety
- Operations that require approval
- Applying to different project types

## Thinking about trust

For any change that handles data or exposes behavior, ask:

1. **Where are the trust boundaries?** Where does data cross from something you do not control (users, network, files, environment, other services, plugins, model output) into code you do?
2. **What assets matter?** Credentials, personal data, money, integrity of records, availability, the host machine.
3. **What can go wrong at each boundary?** Malformed, malicious, oversized, duplicated, out-of-order, replayed, or missing input.
4. **What is the failure behavior?** Fail closed (deny) for security decisions; degrade gracefully for availability where safe.

Use the project's established mechanisms for each control. Do not invent your own cryptography, session handling, or authentication scheme.

## Security controls

- **Input validation**: validate type, shape, range, length, and allowed values at the boundary; reject by default; allow-list fields.
- **Injection** (SQL, shell, template, LDAP, XPath, log, markup): never build commands, queries, or markup by concatenating untrusted data. Use parameterized APIs, argument arrays, and context-aware encoding.
- **Path and file handling**: normalize and constrain paths; guard against traversal and symlink tricks; validate uploads by content and size; use safe temporary files.
- **Deserialization and parsing**: do not deserialize untrusted data into arbitrary objects; cap sizes and depth.
- **Authentication and authorization**: authenticate, then authorize each access to each resource on the server side. Deny by default. Scope data access to the caller (prevent insecure direct object references).
- **Secrets**: never in source, logs, error messages, or client bundles. Read from the environment or a secrets manager. If you find one committed, report it and recommend rotation; do not paste it elsewhere.
- **Cryptography**: use vetted libraries and current defaults; do not roll your own; use the framework's password hashing.
- **Outbound requests**: be wary of user-controlled URLs (SSRF); allow-list destinations where practical; set timeouts and size limits.
- **Secure defaults**: least privilege, restrictive permissions, safe configuration out of the box, explicit opt-in for risky behavior.
- **Data protection**: collect only what is needed; minimize what is logged and returned; protect personal data in transit and at rest as the project requires.
- **Error messages**: informative for operators, minimal for outsiders; no stack traces, SQL, or internals in user-facing output.

## Dependencies and supply chain

- Prefer the standard library and existing dependencies. Add a new one only with a clear need and user approval.
- Evaluate a candidate: maintenance activity, adoption, license compatibility, size, transitive dependencies, known vulnerabilities, install-time scripts.
- Check the package name carefully for typosquatting; install from the project's configured registry.
- Pin versions according to the project's practice (lockfiles committed); do not mass-upgrade as a side effect of another task.
- Run the ecosystem's audit tool when relevant and report results accurately.
- Treat code copied from the internet, generated build steps, and `curl | sh` installers as untrusted; review before running.

## Reliability

- **Timeouts everywhere** a call can block (network, database, subprocess). A missing timeout is a latent outage.
- **Retries**: only for transient failures and idempotent operations; use exponential backoff with jitter and a cap; never retry blindly on validation or authorization errors.
- **Idempotency**: make operations safe to repeat (idempotency keys, upserts, unique constraints, deduplication) wherever messages or clients can retry.
- **Fault isolation**: bound the blast radius with limits, queues, bulkheads, and circuit breakers; one failing dependency should not take down everything.
- **Resource limits**: cap payload sizes, concurrency, queue depth, memory, and result sizes. Unbounded input becomes resource exhaustion.
- **Concurrency safety**: atomic updates, transactions, locks or optimistic versioning for read-modify-write; beware time-of-check to time-of-use.
- **Failure handling**: decide what happens on partial failure; make multi-step operations atomic or compensatable; do not leave data half-written.
- **Graceful degradation**: serve reduced functionality (cached or default data) rather than failing entirely, where that is safe and honest to the user.
- **Recovery**: backups and restore paths, reversible migrations, safe shutdown and restart, state that can be rebuilt.
- **Data integrity**: enforce invariants at the storage layer (constraints, types), not only in application code.

## Observability

- Log **events that matter** (state changes, failures, security-relevant actions) with context (ids, correlation ids), at appropriate levels, in the project's format.
- Never log secrets, tokens, full card or ID numbers, or unnecessary personal data.
- Expose **metrics** for rate, errors, latency, and saturation where the project has a metrics system; add **health checks** where the platform expects them; propagate **trace context** if tracing exists.
- Alert on symptoms users feel, not every internal blip.
- Do not add logging noise; use the existing logger, not `print`.

## Deployment safety

- Keep changes **backward compatible** across the deploy window: old code and new code may run together, and schema and code may deploy in different orders.
- Make risky changes **incremental and reversible**: feature flags, canary or staged rollout, expand-migrate-contract for schemas.
- Know the **rollback plan** before shipping; data changes are the hard part to roll back.
- Treat configuration, secrets, and infrastructure changes as code changes with their own impact analysis.
- Do not change deployment, CI, or production configuration without being asked.

## Operations that require approval

Stop and get explicit confirmation from the user before:

- deleting or overwriting data, files, branches, or tables you did not create;
- anything that touches production or shared environments;
- destructive or irreversible migrations; running migrations on a shared database;
- force-pushing, rewriting history, `reset --hard`, `clean -fd` (see `legacy-and-repo.md`);
- changing credentials, tokens, permissions, or access policies;
- actions with external side effects: sending messages, charging money, publishing, deploying, calling paid APIs at scale;
- installing packages, or running scripts from sources you have not reviewed;
- changes that break a public contract.

Approval for one operation does not extend to similar operations later.

## Applying to different project types

Choose controls for the actual threat model.

- **Web and API services**: the full list above, with emphasis on authz, injection, session handling, CSRF/CORS configuration, rate limiting.
- **CLI tools and scripts**: argument and path handling, shell injection, safe temp files, confirmation before destructive actions, no secrets in shell history or logs.
- **Libraries and SDKs**: input validation on public APIs, no global side effects, safe defaults, careful dependency footprint, stable and documented error behavior.
- **Mobile and desktop apps**: local data storage, platform keystores, transport security, permission requests, update integrity, untrusted deep links and IPC.
- **Data pipelines**: schema and data validation, idempotent reruns, handling of malformed records, access control on datasets, personal data handling.
- **Infrastructure and CI/CD**: least-privilege credentials, no secrets in logs or state files, pinned actions and images, review of third-party steps, drift and plan review.
- **Embedded and systems code**: memory safety, bounds checking, integer overflow, interrupt and concurrency safety, watchdogs, update and recovery paths.
