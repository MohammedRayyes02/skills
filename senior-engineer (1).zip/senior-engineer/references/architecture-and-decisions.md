# Architecture and Decisions

Read this when choosing between designs, drawing module boundaries, changing contracts or schemas, planning a migration, assessing what a change affects, or deciding whether to write something down.

## Contents
- Decision procedure
- Trade-offs
- Principles as questions
- Architecture reasoning
- Compatibility and migration
- Change impact analysis
- Decision records
- Documentation

## Decision procedure

For any decision that is not trivial:

1. **Restate the problem** in terms of what must be true afterwards, not the first solution that came to mind.
2. **List constraints**: existing architecture, public contracts, data already stored, team conventions, deadlines, environment.
3. **Generate options**: at least the smallest change that works, the conventional approach in this codebase, and one alternative. "Do less" and "reuse what exists" are always candidates.
4. **Compare on what matters here**: correctness, complexity added, blast radius, reversibility, performance need, operational cost, how much the team must learn.
5. **Choose the simplest option that meets the actual requirements**, and note what would make you revisit it.
6. **State the consequence** to the user in a sentence when it is not obvious (new dependency, migration needed, behavior change, deferred work).

Spend effort in proportion to reversibility. A private helper can be changed in a minute; a public endpoint, a database column, a file format, or a dependency lives for years.

## Trade-offs

| Tension | Lean toward the left when... | Lean toward the right when... |
|---|---|---|
| Simplicity vs flexibility | requirements are known and stable; one use case exists | a second concrete use case exists, or variation is already scheduled |
| Performance vs maintainability | no measured problem; code is not on a hot path | profiling shows a bottleneck that matters to users or cost |
| Abstraction vs direct code | the shared part is small or the cases may diverge | the same concept is duplicated, changes together, and has a stable shape |
| Speed now vs long-term cost | throwaway, prototype, or reversible work | code on a critical path, public interface, or data model |
| Reliability vs complexity | failure is cheap or recoverable | failure loses data, money, or trust; complexity is contained (timeouts, idempotency) |
| Compatibility vs improvement | many consumers, unknown consumers, published API | internal-only interface with every caller under your control |
| Consistency with project vs "better" way | always the default; consistency lowers cognitive load | the project's way is unsafe or broken; raise it, then follow the user's decision |

State which side you chose and why when the choice is non-obvious. Do not present a preference as a requirement.

## Principles as questions

Use each principle as a diagnostic question. Skip it when the answer is "no problem here".

- **Single responsibility**: how many different reasons would force this to change? Split only where the reasons are genuinely independent.
- **Open/closed**: is there real, present variation (several payment providers, several formats)? If yes, a seam helps. If not, edit the code when the need arrives.
- **Liskov and interface segregation**: can a substitute really honor the contract? Do callers depend on methods they never use? These matter where you actually have polymorphism or published interfaces.
- **Dependency inversion**: do you need to swap or fake this dependency (testing, multiple backends)? If so, depend on a narrow interface. If there will only ever be one implementation and tests can use it directly, do not add one.
- **DRY**: is this the same knowledge expressed twice, or merely similar-looking code? Merge the first; leave the second. Waiting for a third occurrence is a reasonable heuristic, not a law.
- **KISS**: could a newcomer explain this in two sentences? If not, find what is making it complicated.
- **YAGNI**: is anything here built for a case nobody has asked for? Remove it. Exception: do not make irreversible choices carelessly (public API shape, schema, security boundary) just to be minimal; think those through now.
- **Composition over inheritance, explicit over implicit, make invalid states unrepresentable**: useful defaults when the language supports them; follow the codebase's idiom.

## Architecture reasoning

- **Start from what exists.** Identify the boundaries (modules, packages, services, layers), the direction dependencies point, where data enters and leaves, and where state lives. Fit your change into that structure; do not reshape it as a side effect.
- **Coupling and cohesion.** Keep things that change together close; keep things that change independently apart. Watch for shared mutable state, circular dependencies, and modules that know each other's internals.
- **Dependency direction.** Stable, high-level policy should not depend on volatile details (frameworks, I/O, vendors). Check imports: a domain module importing a UI or HTTP library is a smell.
- **Contracts.** Treat every boundary (function signature, API, event, file format, database schema) as a contract with consumers. Make it explicit, validated at the edge, and changed deliberately.
- **Data flow.** Be able to trace a piece of data from source to sink. Unclear ownership of data is the root of most consistency bugs.
- **Simple vs structured.** A small script, an internal tool, or a single-feature app is well served by flat, direct code. Introduce layers, services, or message passing only when you can name the problem they solve: independent deployment, team boundaries, divergent scaling, isolation of a volatile dependency, testability that is otherwise impossible.
- **Scalability.** Design for roughly the next order of magnitude of load and data, not for a hypothetical thousandfold. Know the likely bottleneck (database, memory, a single queue) and avoid choices that close off the obvious fix.
- **Extensibility.** Place seams where change is actually expected and observed in the project's history; leave the rest simple.

## Compatibility and migration

- **Prefer additive change**: add fields, endpoints, and options rather than altering meaning. Make new parameters optional with the old behavior as the default.
- **Expand, migrate, contract** for schemas and interfaces: add the new form alongside the old, move consumers over, then remove the old form in a later change. Each step should be deployable on its own and reversible.
- **Strangler pattern** for replacing a subsystem: route a slice of behavior to the new implementation, grow it, retire the old.
- **Feature flags** to decouple deploy from release, when the project already uses them or the risk justifies them.
- **Deprecate before removing**: mark, document, give a timeline, and check usage before deleting.
- **Data migrations**: make them idempotent and resumable, test on realistic data, batch large updates, know how to roll back or forward, and never edit a migration that has already been applied elsewhere.
- Breaking changes need explicit user agreement and an update of every known consumer.

## Change impact analysis

Scale it to risk (see "Scale the effort" in `SKILL.md`). For simple local changes, a quick search of call sites is enough. For significant changes, check what applies:

| Area | How to find out |
|---|---|
| Callers and dependents | search for usages (`grep`/language server/type checker); follow re-exports and dynamic lookups (strings, reflection, config) |
| Public interfaces and API contracts | check API schemas, OpenAPI/GraphQL files, exported symbols, generated clients, docs |
| Database schema and data | migrations, ORM models, raw queries, indexes, existing rows, backfills, constraints |
| Background jobs, queues, schedulers | search for job names, handlers, cron definitions, message schemas in flight |
| External integrations and webhooks | search for client code and contracts; consider consumers you cannot see |
| Configuration and environment | env vars, config files, feature flags, secrets, per-environment differences |
| Build, CI, and deployment | pipelines, Dockerfiles, deploy scripts, rollout order (does code or schema ship first?) |
| Tests | tests that cover the area, tests that will need updating, gaps |
| Docs and downstream consumers | README, guides, changelogs, examples, other repositories or teams |

Record what you checked and what you could not check. "I did not verify external consumers" is an honest and useful statement.

## Decision records

Write a brief record only when a decision is hard to reverse, crosses module boundaries, adds a dependency or pattern, or rejects an option a reader would reasonably expect. Do not write one for routine changes.

- Put it where the project already keeps such things (`docs/adr/`, a decisions file, the PR description, or the code comment at the point of decision). Do not invent a new documentation system.
- Keep it short: **context**, **decision**, **alternatives considered and why not**, **consequences** (including what would trigger a revisit).

## Documentation

- Read existing docs before assuming behavior; they may be stale, so confirm against the code.
- Update README, API docs, examples, changelog, and migration notes when your change makes them wrong or incomplete. This is part of the change, not scope creep.
- Document **why** and **constraints**: non-obvious decisions, invariants, units, ordering requirements, known limitations, operational procedures.
- Do not duplicate what the code or an existing document already says; link to it.
- Verify code samples still run or at least still match the real signatures.
- Do not generate summaries, change-log files, or explanatory documents nobody asked for.
