# Legacy Systems and Repository Discipline

Read this when the working tree has changes, before committing or using Git beyond reading, when working in older or poorly tested code, or when deciding what to do about technical debt.

## Contents
- Before editing: inspect the tree
- While working
- Before finishing: review the diff
- Commits
- Destructive commands and safer alternatives
- Legacy code
- Characterization tests
- Technical debt
- When a rewrite is justified

## Before editing: inspect the tree

Run `git status` and, when anything is modified, `git diff` (and `git stash list`, `git branch --show-current` when relevant).

- Note which files are **already modified or untracked** before you start. That is the baseline; those changes belong to the user (or another process), not to you.
- If the files you need to change already have uncommitted modifications, read them first and work **with** them. Do not revert, reformat, or "tidy" them. If your change conflicts with them, ask.
- Check the current branch. Do not commit to or push a protected or unexpected branch.
- Not a Git repository? Be more careful, not less: make smaller changes and tell the user what you changed so they can back it up.

## While working

- Keep the change set focused; one concern per set of changes.
- Do not assume every modification you see is yours, and do not assume it is not. Track what you changed.
- Do not run formatters or code generators over the whole repository; run them only on files you touch, and check the result for unrelated churn.
- Do not commit unless the user asks you to (or the project workflow clearly expects it). Never push unless asked.
- Never bypass hooks or checks (`--no-verify`) to get a commit through; fix the cause.
- Never commit secrets, local config, build output, or large generated files. Check `.gitignore`.

## Before finishing: review the diff

Read the complete `git diff` (and `git status` for untracked files) as a reviewer would:

- Is every changed file intentional? Remove accidental edits (stray formatting, editor artifacts, debug statements, `console.log`, `TODO` you added, commented-out code).
- Did lockfiles, generated files, or snapshots change? Is that expected for this change?
- Whitespace-only or line-ending changes across many lines? Investigate and undo the noise.
- Compare against the baseline you noted: your diff should contain your changes, and the user's changes should be untouched.
- Are there new files that should or should not be tracked?

Mention anything unexpected in the report rather than silently fixing or ignoring it.

## Commits

When the user wants commits, or you suggest them:

- **Logical units**: separate refactoring from behavior change, formatting from logic, dependency updates from feature work, and tests with the code they cover (or immediately after).
- **Each commit builds and passes tests** where practical.
- **Messages**: follow the repository's existing style (`git log` shows it, e.g. Conventional Commits or plain sentences). Describe why, not just what. Keep the subject concise.
- Stage explicitly (`git add <paths>`), not `git add -A`, so you do not sweep in unrelated changes.
- Do not amend or rewrite history that has been shared.

## Destructive commands and safer alternatives

Ask before running any of these. If approval is given, state exactly what will be lost.

| Command | Risk | Safer alternative |
|---|---|---|
| `git reset --hard` | discards uncommitted work | `git stash` (and tell the user), or `git restore <specific file>` for your own changes |
| `git checkout -- .` / `git restore .` | discards uncommitted work | restore specific files you modified |
| `git clean -fd` / `-fdx` | deletes untracked (possibly unrecoverable) files | `git clean -n` first to preview; delete specific files only |
| `git push --force` | overwrites remote history | `--force-with-lease` with approval, or a new branch |
| `git rebase` / `commit --amend` on shared commits | rewrites history others rely on | new commit, or do it on your own unpushed branch |
| `git branch -D`, `git stash drop` | loses unmerged or stashed work | confirm with the user first |
| `rm -rf`, mass `mv`, overwrite redirects `>` | irrecoverable loss | targeted paths, preview with `ls`, work on copies |

Prefer reversible alternatives. When something went wrong, stop and report instead of "fixing" with a destructive command.

## Legacy code

Legacy code is code whose behavior you cannot fully predict from reading it, often with few tests. It still runs the business. The job is to change it safely.

1. **Understand current behavior first**: read the code and its callers, check history (`git log`, `git blame`) for why things are the way they are, run it, and look at real inputs. Odd-looking code often encodes a bug fix or an external constraint. Do not delete it until you know why it exists.
2. **Respect established conventions**, including old ones. Do not modernize style or APIs as a side effect of another task.
3. **Prefer incremental improvement**: a small, safe step that leaves the area slightly better, verified, rather than a sweeping rewrite.
4. **Separate structural and behavioral changes**: refactor with behavior fixed (tests unchanged), then change behavior in a separate step, or vice versa. Never both in one unreviewable change.
5. **Find seams**: places where you can change behavior without editing the code under test (function boundaries, injected dependencies, configuration, interfaces) so you can test and substitute.
6. **Preserve compatibility**: public behavior, data formats, and quirks consumers may rely on. Treat observable behavior as the contract, not the documentation.
7. **Limit your scope**: improve what the task touches. Note other weaknesses; do not fix every one.
8. **Remove dead code only with evidence** (no references, no dynamic use, no external consumers, confirmed unused), and in its own change.

## Characterization tests

When code you must change has no tests, pin its current behavior first:

1. Choose the unit or entry point you will change.
2. Call it with realistic inputs, including edge cases and error cases; record what it actually returns or does (use real examples from logs or fixtures where possible).
3. Assert that current behavior, even where it looks wrong. The test documents "what it does now," not "what it should do."
4. Make your change; the tests should still pass for everything you did not intend to change.
5. Where current behavior is a bug, note it, and fix it as a separate, intentional step with the test updated deliberately.

If the code cannot be tested without invasive changes, make the smallest change that creates a seam (extract a function, pass a dependency in) and verify it by hand or with an end-to-end check.

## Technical debt

- **Classify**: debt that **blocks** the task, debt that **slows** the team repeatedly, and **cosmetic** debt. Only the first may justify action inside the current change, and only the minimum needed.
- **Prioritize by interest**: debt in code that changes often or sits on critical paths costs more than debt in code nobody touches.
- **Record rather than fix**: mention it in the report or in the project's usual place (issue tracker, `TODO` with context if the project uses them). Do not leave anonymous TODOs.
- **Do not add debt knowingly** to move faster; if a shortcut is necessary, say so, scope it, and note how to pay it back.
- Offer cleanups as separate, optional work with a clear benefit.

## When a rewrite is justified

Rare. Consider it only when most of these hold: the code is not understandable or changeable at acceptable cost; the platform or dependency is unsupported or insecure; the incremental path is demonstrably more costly; behavior is well specified or testable; the user has decided to spend the effort. Even then, prefer replacing piece by piece (strangler approach, see `architecture-and-decisions.md`) over a big-bang rewrite, and get explicit approval first.
