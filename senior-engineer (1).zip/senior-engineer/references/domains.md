# Domain Notes

Read the section that matches the project. The core workflow in `SKILL.md` applies everywhere; these notes cover what changes by domain. Web UIs are in `frontend.md`, server-side web services in `backend.md`. Detect the actual stack and follow its conventions; these notes are principles, not language-specific rules.

## Contents
- Mobile and desktop applications
- Databases and data engineering
- Distributed systems and APIs
- Infrastructure, DevOps, and CI/CD
- Systems and embedded programming
- CLI tools
- Libraries and SDKs
- Automation and developer tooling
- Testing and quality engineering

## Mobile and desktop applications

- Respect the platform: its UI conventions, lifecycle (suspend, background, kill), permission model, and accessibility services. Use the official frameworks and patterns before third-party ones.
- Keep work off the UI thread; avoid blocking calls; handle slow, absent, or flaky networks and offline state deliberately.
- Plan for process death and restoration: persist state that must survive, never assume memory persists.
- Mind battery, memory, startup time, and binary size; profile on real or representative devices.
- Store secrets in the platform keystore; treat deep links, IPC, and clipboard as untrusted input.
- Version and migrate local data carefully; old app versions and old data stay in the field for a long time.
- Verify on multiple OS versions and screen sizes; check localization, right-to-left layout, and text scaling.

## Databases and data engineering

- **Schema design**: model the domain; use constraints (keys, uniqueness, not-null, foreign keys) to enforce invariants; choose types and units deliberately; avoid storing derived data unless justified.
- **Queries**: check query plans on realistic data; add indexes for real access patterns, remembering they cost writes; avoid unbounded scans and N+1 access.
- **Migrations**: forward-safe and reversible where possible; avoid long locks on large tables (add nullable, backfill in batches, then constrain); never edit applied migrations; test on production-like data volume.
- **Transactions and consistency**: know the isolation level and what anomalies it allows; keep transactions short; design for retries.
- **Pipelines**: make jobs **idempotent** and re-runnable; validate schemas and quality at ingestion; handle late, duplicate, and malformed records explicitly; log row counts and rejects; separate raw, cleaned, and derived data; be careful with time zones, null semantics, and floating-point money.
- **Data safety**: never run destructive statements against shared or production data without approval; test transformations on samples; preserve the ability to reprocess.

## Distributed systems and APIs

- Assume the network is unreliable: timeouts, retries with backoff, idempotency, and clear failure semantics on every remote call.
- Be explicit about consistency (what can be stale, what must be atomic) and ordering and delivery guarantees (at-most-once, at-least-once); design consumers to tolerate duplicates.
- Version contracts; evolve additively; check all consumers (see compatibility in `architecture-and-decisions.md`).
- Avoid distributed transactions where possible; prefer sagas or compensations and make state transitions explicit.
- Propagate correlation ids; log and measure at service boundaries; design health checks and graceful shutdown.
- Do not split a system into services without a concrete reason (independent scaling or deployment, team boundary, fault isolation). A well-structured monolith is a valid answer.
- Verify with contract tests and failure-injection (timeouts, partial outages), not only happy-path calls.

## Infrastructure, DevOps, and CI/CD

- Treat infrastructure as code: declarative where the tool supports it, reviewed, and versioned. Review the plan or diff output before applying anything.
- **Never apply changes to real environments without approval.** Prefer dry-runs, plan modes, and non-production first.
- Least privilege for credentials and roles; no secrets in repositories, images, state files, or logs; pin versions of base images, actions, and tools.
- Make pipelines fast, deterministic, and cached sensibly; fail early; keep the pipeline's commands runnable locally.
- Changes should be incremental, reversible, and observable; know the rollback path; watch for drift and for ordering between infrastructure, schema, and code deploys.
- Keep configuration per environment explicit and validated; do not hard-code environment specifics.
- Verify by linting, validating, planning, and, when allowed, applying to a disposable environment.

## Systems and embedded programming

- Memory and resource discipline: ownership, lifetimes, bounds checks, integer overflow, uninitialized data; follow the language's safety idioms (and avoid undefined behavior).
- Understand the constraints: memory, stack depth, real-time deadlines, interrupt context, power. Avoid dynamic allocation, blocking calls, or heavy work where the environment forbids them.
- Concurrency and interrupts: define what is shared, protect it with the right primitives, keep critical sections minimal, mind memory ordering.
- Hardware and ABI boundaries are contracts: respect endianness, alignment, packing, register semantics, and documented timing.
- Defensive design for the field: watchdogs, safe states, recoverable updates, versioned persistent data.
- Verify with sanitizers, static analysis, warnings-as-errors, simulation or hardware-in-the-loop where available; state clearly what could not be tested without hardware.
- Prefer small, explicit, portable code; isolate platform-specific parts.

## CLI tools

- Predictable interface: clear subcommands and flags following the ecosystem's conventions, helpful `--help`, consistent naming, sensible defaults.
- Correct exit codes (zero for success, nonzero for failure), errors to stderr, data to stdout; support machine-readable output when useful; behave well in pipes and non-interactive environments.
- Confirm or require an explicit flag before destructive actions; support dry-run where it makes sense.
- Handle paths, encodings, spaces, and platform differences; validate arguments early with clear messages.
- Do not change flags or output formats that scripts may depend on without treating it as a breaking change.
- Test by running the tool with real arguments, including failure cases and edge inputs.

## Libraries and SDKs

- The public API is the product: keep it small, consistent, and hard to misuse; every exported symbol is a long-term commitment.
- Follow semantic versioning in spirit: additive changes in minor versions, breaking changes only deliberately and documented, with deprecation first.
- Minimize dependencies and global state; avoid side effects at import time; make behavior configurable by the caller, not by environment surprises.
- Define error behavior explicitly (types, messages, what callers can handle).
- Document public APIs with accurate, runnable examples; keep the changelog and migration notes current.
- Support the platform and language versions the project declares; test across them if CI does.
- Verify public-API compatibility (type checks, API diff tools) when changing exported surfaces.

## Automation and developer tooling

- Make scripts safe by default: idempotent, with dry-run, clear logging, and failure on error rather than continuing silently.
- Do not hard-code machine-specific paths or credentials; read configuration from arguments or environment.
- Keep tools small and single-purpose; reuse existing task runners and conventions (Makefile, npm scripts, justfile) instead of adding new ones.
- Document how to run them in the place developers will look.
- Be careful with tools that touch many files or external systems; preview before applying.

## Testing and quality engineering

- Design the test strategy around risk: more tests where failure is costly or the logic is intricate, fewer where it is trivial.
- Keep the test suite fast, reliable, and meaningful; flaky tests should be fixed or quarantined with a recorded reason, not ignored.
- Maintain test data and fixtures deliberately; avoid hidden dependencies between tests.
- Treat CI failures as signals; investigate rather than rerun until green.
- Details on test types, quality, and reporting: `verification-and-performance.md`.
