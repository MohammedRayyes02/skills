# Examples: How This Skill Changes Decisions

Each example shows the tempting default, what a senior engineer does instead, and why.

## Contents
1. Reuse before creating
2. Abstraction before it is needed
3. Scope discipline
4. Failing test
5. Object-level authorization
6. N+1 query
7. Frontend states and semantics
8. Asking vs assuming
9. Honest reporting
10. Root cause versus symptom
11. Classifying review findings
12. Dirty working tree
13. Legacy code: pin behavior first
14. Performance: measure first
15. When an abstraction is justified
16. Effort matches the change
17. A non-web domain: CLI tool

---

## 1. Reuse before creating

**Task:** format a price in the order summary.

**Bad:** write a new `formatPrice()` inside the component.
**Good:** search first (`grep -ri "currency\|formatMoney\|Intl.NumberFormat" src/`), find `lib/money.ts: formatMoney`, import it.
**Why:** a second formatter drifts from the first (rounding, locale) and creates two places to fix.

## 2. Abstraction before it is needed

**Task:** add CSV export for orders; users export reports too, later.

**Bad:**
```python
class ExporterFactory:
    def create(self, kind): ...
class AbstractExporter(ABC): ...
class OrderExporter(AbstractExporter): ...
```
Factory, abstract base, and one implementation, for a need that exists once.

**Good:**
```python
def orders_to_csv(orders):
    ...
```
When the second export arrives and the shared part is visible, extract the shared writer then (compare example 15, where the abstraction is justified).
**Why:** an abstraction guessed from one example usually fits the wrong axis of change.

## 3. Scope discipline

**Task:** fix the date shown on the invoice page (off by one day for some users).

**Bad:** fix the bug, also rename variables, reformat the file, upgrade the date library, convert the class to hooks.
**Good:** fix the timezone handling in the one function, add a regression test, and write: "Noticed `formatDate` is duplicated in `ReportRow`; not changed, want me to unify it?"
**Why:** the diff stays reviewable and revertable; the cleanup stays the user's decision.

## 4. Failing test

**Situation:** after the change, `test_total_includes_tax` fails.

**Bad:** change the expected value to match the output, or mark the test skipped.
**Good:** work out which is wrong. If the test encodes the real rule, fix the code. If the rule legitimately changed per the requirement, update the test and say so explicitly in the report.
**Why:** a test edited to pass proves nothing, and silent edits hide behavior changes.

## 5. Object-level authorization

**Task:** add `GET /documents/{id}`.

**Bad:**
```js
const doc = await Document.findById(req.params.id);
res.json(doc);
```
Any logged-in user can read any document by guessing ids.

**Good:**
```js
const doc = await Document.findOne({ _id: req.params.id, ownerId: req.user.id });
if (!doc) return res.status(404).json({ error: "Not found" });
res.json(doc);
```
Or use the project's policy/guard mechanism if one exists.
**Why:** insecure direct object reference is one of the most common real vulnerabilities; ownership must be part of the lookup.

## 6. N+1 query

**Task:** list projects with their owner names.

**Bad:**
```php
foreach (Project::all() as $project) {
    echo $project->owner->name;   // one extra query per row
}
```
**Good:**
```php
$projects = Project::with('owner:id,name')->paginate(25);
```
**Why:** 1 + N queries become 2, and the unbounded `all()` becomes a page.

## 7. Frontend states and semantics

**Task:** show a list of tasks fetched from an API.

**Bad:** render `tasks.map(...)` only; blank screen while loading, on error, and when empty. Rows are `<div onClick>`.

**Good:** loading skeleton, error message with retry, empty state with "Create your first task", rows as real links/buttons with labels, keyboard operable.
**Why:** users spend most of their time in the non-happy states; semantic elements give keyboard and screen-reader support for free.

## 8. Asking vs assuming

**Case A (ask):** "Add role-based access." Which roles, which resources, and who assigns them are unknown and change the data model. Ask one focused question before building.

**Case B (assume):** "Add a `createdAt` sort to the list." Descending is the obvious default and trivially changed. Implement it, state "sorted newest first", move on.
**Why:** ask when a wrong guess is expensive; assume when it is cheap to undo.

## 9. Honest reporting
10. Root cause versus symptom
11. Classifying review findings
12. Dirty working tree
13. Legacy code: pin behavior first
14. Performance: measure first
15. When an abstraction is justified
16. Effort matches the change
17. A non-web domain: CLI tool

**Bad:** "Implemented the feature and all tests pass." (tests were never run)

**Good:**
> Implemented password reset in `AuthController` and `PasswordResetService`. Token expiry is 60 min, matching the existing email-verification setting.
> Verified: ran `php artisan test --filter=PasswordReset` (6 passed) and `./vendor/bin/pint --test` (clean). Not verified: actual email delivery (no mail server in this environment).
> Risk: no rate limit on the reset endpoint yet; recommend adding one.

**Why:** the reader can trust what was checked and knows exactly what remains.

---

## 10. Root cause versus symptom

**Situation:** `TypeError: cannot read 'email' of undefined` in the order confirmation job.

**Bad:** `const email = order.user?.email ?? ""`. The error disappears; customers silently stop receiving confirmations.
**Good:** trace why `order.user` is missing. Finding: orders created via the import tool skip user linking. Fix the import to link users, add a test that imports an order and expects a confirmation, and search for other code assuming `order.user` exists.
**Why:** the null check hid a data problem; the real fix removes the cause and guards against the whole class.

## 11. Classifying review findings

**Task:** review a pull request that adds a retry loop around payment capture.

**Bad:** "This will double-charge customers!" (unverified), mixed in with "rename `tmp` to `temporary`".
**Good:**
```
[Critical | Potential risk] payments/capture.py:41
Retrying capture() on any exception may charge twice if the first request succeeded but the response timed out.
Not confirmed: I could not find an idempotency key on the request. Confirm by checking whether the provider call passes one; if not, this is a confirmed defect.

[Low | Preference] payments/capture.py:12
`tmp` could be named more descriptively. No project rule; ignore if you disagree.
```
**Why:** the reader knows what is proven, what is suspected, how to resolve it, and what to prioritize.

## 12. Dirty working tree

**Situation:** `git status` shows 4 modified files before you start; you need to edit one of them.

**Bad:** `git stash` or `git checkout .` "for a clean slate", or reformat the whole file, mixing your change into the user's uncommitted work.
**Good:** note the baseline, read the user's existing edits in that file, make your change around them, stage only your files if asked to commit, and mention in the report: "`settings.py` already had your uncommitted changes; I edited only the `TIMEOUT` block."
**Why:** the user's work is not yours to discard, and a clean diff shows exactly what you did.

## 13. Legacy code: pin behavior first

**Task:** add a discount rule to a 600-line `calculate_total()` with no tests.

**Bad:** rewrite it into clean strategy classes, then add the discount. Nobody can tell whether old totals changed.
**Good:** write characterization tests from real order samples that record current outputs (including odd rounding). Add the discount in the smallest place that fits, confirm old cases are unchanged, and list the legacy oddities noticed as follow-ups.
**Why:** the tests turn "I think I did not break it" into evidence, and the rewrite stays an optional, separate decision.

## 14. Performance: measure first

**Report:** "The dashboard is slow."

**Bad:** add a cache layer and an index based on a guess.
**Good:** time the endpoint; the profiler shows 90% of the time in 400 near-identical queries (an N+1). Replace with one joined query, re-measure (p95 1.9 s to 140 ms), and skip the cache.
**Why:** the bottleneck was structural; a cache would have added invalidation bugs and left the real problem.

## 15. When an abstraction is justified

**Task:** add a third payment provider (the code already has two near-identical provider-specific code paths, each duplicating retry, logging, and error mapping).

**Bad (opposite failure):** copy-paste a third time, because "abstractions are bad".
**Good:** extract a small `PaymentProvider` interface (`charge`, `refund`) and move the shared retry and error mapping into one place, then implement the third provider against it. Three real cases and genuinely shared behavior justify it.
**Why:** the rule is not "never abstract"; it is "abstract when the duplication and the axis of change are real and present."

## 16. Effort matches the change

**Task:** fix a typo in an error message.

**Bad:** a four-option analysis, an implementation plan, a full test run, and a report with five sections.
**Good:** change the string, check it is not referenced by tests or translations, run the relevant test or lint if quick, and say: "Fixed the typo in `errors.ts:23`; no test references the old text."
**Why:** process should scale with risk; ceremony on trivial changes wastes the user's time and trust.

## 17. A non-web domain: CLI tool

**Task:** add a `--delete-old` option to a log-cleanup CLI.

**Bad:** delete immediately, exit 0 even if some deletions fail, print errors to stdout.
**Good:** add a `--dry-run` listing what would be deleted, require the explicit flag for deletion, print errors to stderr, return a nonzero exit code if any deletion failed, and test with a temporary directory including a read-only file.
**Why:** destructive action needs a preview, and scripts depend on exit codes and streams; web checklists (CSRF, status codes) do not apply here, the principles do.

